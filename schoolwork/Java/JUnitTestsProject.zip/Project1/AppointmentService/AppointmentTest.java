package main.java;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;


class AppointmentTest {

    // test to make sure appointments array is initialized as empty ArrayList
    @Test
    void testAppointmentsList() {
        long millis=System.currentTimeMillis();
        Date date = new Date(millis + 1000);
        Appointment appointment = new Appointment("123456789", date, "test description");

        assertTrue(appointment.getId().equals("123456789"));
        assertTrue(appointment.getDescription().equals("test description"));
        assertTrue(appointment.getDate().equals(date));
    }

    // Id tests
    @Test
    void testIdTooLong() {

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567811122331", new Date(), "Doe");
        });
    }
    @Test
    void testIdNull( ) {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, new Date(), "Doe");
        });
    }


    // Date tests
    @Test
    void testDateBeforeCurrent() {
        // new Date(1000) means 1 second after January 1, 1970, 00:00:00 GMT.
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678", new Date(1000), "test description");
        });
    }
    @Test
    void testDateNull( ) {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678", null, "Doe");
        });
    }


    // Description tests
    @Test
    void testDescriptionTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678", new Date(), "123 Main St. This String is Way too long"
                    + "											 Because it is greater than 50 characters in length");
        });
    }
    @Test
    void testDescriptionNull( ) {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678", new Date(), null);
        });
    }

    @Test
    void testSetDescription() {
        Appointment appointment = new Appointment("12345678", new Date(), "test description");
        appointment.setDescription("new description");

        assertTrue(appointment.getDescription().equals("new description"));
    }



}




