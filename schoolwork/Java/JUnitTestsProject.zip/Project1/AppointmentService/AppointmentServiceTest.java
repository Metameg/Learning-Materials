package main.java;

import org.junit.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;


//import appointment.Appointment;
//import appointment.AppointmentService;

class AppointmentServiceTest {

    // test to make sure appointments array is initialized as empty ArrayList
    @Test
    void testAppointmentsList() {
        AppointmentService appointmentService = new AppointmentService();

        assertTrue(appointmentService != null);
        appointmentService.addAppointment("123455");
        assertTrue(appointmentService.appointments != null);
    }

    // add existing appointment test
    @Test
    void testAddExistingappointment() {
        AppointmentService appointmentService = new AppointmentService();

        // Add first appointment
        appointmentService.addAppointment("12345678");
        assertTrue(appointmentService.appointments.size() != 0);
        // add second appointment with same ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment("12345678");
        });
    }

    // Delete non-existing appointment test
    @Test
    void testDeleteNonExistingAppointment() {
        AppointmentService appointmentService = new AppointmentService();

        // Add first appointment
        appointmentService.addAppointment("12345678");

        // Try to remove non-existing appointment
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("11111111");
        });
    }

    // Delete existing appointment test
    @Test
    void testExistingAppointment( ) {
        AppointmentService appointmentService = new AppointmentService();

        // Add first appointment
        appointmentService.addAppointment("12345678");

        // Remove existing appointment
        appointmentService.deleteAppointment("12345678");

        // Test that appointment was removed and appointments ArrayList is empty again
        assertTrue(appointmentService.appointments.size() == 0);
    }

    // Update description test
    @Test
    void testUpdatDescription() {
        AppointmentService appointmentService = new AppointmentService();

        // Add appointment with a unique id, default description should be "test description"
        appointmentService.addAppointment("11111111");
        Appointment testAppointment = appointmentService.appointments.get(0);
        assertTrue(testAppointment.getDescription().equals("test description"));

        // Update description to "1111111111"
        testAppointment.setDescription("1111111111");
        assertTrue(testAppointment.getDescription().equals("1111111111"));
    }



}
