package task;

import java.util.ArrayList;

import task.Task;

public class TaskService {
	public ArrayList<Task> tasks;
		
		//Constructor
		public TaskService() {
			this.tasks = new ArrayList<Task>();
		}
		
	public void addTask(String id) {
		// if tasks list is empty, add new Task
		if (tasks.size() == 0) {
			Task newTask = new Task(id, "Jon Doe", "test description");
			tasks.add(newTask);
			return;
		}
		// else, check if id exists, if not, add id
		else {
			for (int i = 0; i < tasks.size(); i++) {
				if (tasks.get(i).getId().equals(id)) {
					throw new IllegalArgumentException("ID already exists");
				}				
			}
			
		Task newTask = new Task(id, "Jon Doe", "test description");
		tasks.add(newTask);
			
		}
	}
		
	// Delete Task method
	public void deleteTask(String id) {
		// If Task id found, remove Task
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getId().equals(id)) {
				tasks.remove(i);
				return;
			}				
		}
		// If no ID not found, throw exception
		throw new IllegalArgumentException("ID doesn't exist");
		
	}
	
	public void updateName(String id, String name) {
		for (int i = 0; i < tasks.size(); i++) {
			Task currTask = tasks.get(i); 
			if (currTask.getId().equals(id)) {
				currTask.setName(name);
				return;
			}				
		}
	}
	
	public void updateDescription(String id, String description) {
		for (int i = 0; i < tasks.size(); i++) {
			Task currTask = tasks.get(i); 
			if (currTask.getId().equals(id)) {
				currTask.setDescription(description);
				return;
			}				
		}
	}
}