package contact;

import java.util.ArrayList;

public class ContactService {
	public ArrayList<Contact> contacts;
	
	//Constructor
	public ContactService() {
		this.contacts = new ArrayList<Contact>();
	}
	
	// Add contact method
	public void addContact(String id) {
		// if contacts list is empty, add new contact
		if (contacts.size() == 0) {
			Contact newContact = new Contact(id, "Jon", "Doe", "1234567890", "123 Main St.");
			contacts.add(newContact);
			return;
		}
		// else, check if id exists, if not, add id
		else {
			for (int i = 0; i < contacts.size(); i++) {
				if (contacts.get(i).getId().equals(id)) {
					throw new IllegalArgumentException("ID already exists");
				}				
			}
			Contact newContact = new Contact(id, "Jon", "Doe", "1234567890", "123 Main St.");
			contacts.add(newContact);
			
		}
	}
	
	// Delete contact method
	public void deleteContact(String id) {
		// If contact id found, remove contact
		for (int i = 0; i < contacts.size(); i++) {
			if (contacts.get(i).getId().equals(id)) {
				contacts.remove(i);
				return;
			}				
		}
		// If no ID not found, throw exception
		throw new IllegalArgumentException("ID doesn't exist");
		
	}
	
	public void updateFirstName(String id, String name) {
		for (int i = 0; i < contacts.size(); i++) {
			Contact currContact = contacts.get(i); 
			if (currContact.getId().equals(id)) {
				currContact.setFirstName(name);
				return;
			}				
		}
		
		// If no ID not found, throw exception
		throw new IllegalArgumentException("ID doesn't exist");
	}
	
}
