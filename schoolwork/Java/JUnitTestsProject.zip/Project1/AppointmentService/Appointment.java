package main.java;

import java.util.Date;
public class Appointment {
    private String id;
    private Date date;
    private String description;

    public Appointment(String id, Date date, String description) {


        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Invalid ID");
        }
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException("Date must be after current date");
        }
        if (description== null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }

        this.id = id;
        this.date = date;
        this.description = description;
    }

    // Getter functions
    public String getId() {
        return this.id;
    }
    public Date getDate() {
        return this.date;
    }
    public String getDescription() {
        return this.description;
    }

    // Setter functions
    public void setDescription(String description) {
        this.description = description;
    }
}