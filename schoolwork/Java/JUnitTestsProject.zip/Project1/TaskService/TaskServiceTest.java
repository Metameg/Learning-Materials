package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import task.Task;
import task.TaskService;

class taskServiceTest {

	// test to make sure tasks array is initialized as empty ArrayList
	@Test
	void testTasksList() {
		TaskService taskService = new TaskService();
		
		assertTrue(taskService.tasks.size() == 0);
	}
	
	// add existing task test
	@Test
	void testAddExistingtask() {
		TaskService taskService = new TaskService();
		
		// Add first task
		taskService.addTask("12345678");
		assertTrue(taskService.tasks.size() != 0);
		// add second task with same ID
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			taskService.addTask("12345678");
		});
	}
	
	// Delete non-existing task test
	@Test
	void testDeleteNonExistingTask() {
		TaskService taskService = new TaskService();
		
		// Add first task
		taskService.addTask("12345678");
		
		// Try to remove non-existing task
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			taskService.deleteTask("11111111");
		});
	}
	
	// Delete existing task test
	@Test
	void testExistingtask( ) {
		TaskService taskService = new TaskService();
		
		// Add first task
		taskService.addTask("12345678");
		
		// Remove existing task
		taskService.deleteTask("12345678");
		
		// Test that task was removed and tasks ArrayList is empty again
		assertTrue(taskService.tasks.size() == 0);
	}
	
	
	// Update Name test
		@Test
		void testUpdateName() {
			TaskService taskService = new TaskService();
			
			// Add task with a unique id, default firstName should be "Doe"
			taskService.addTask("11111111");
			Task testTask = taskService.tasks.get(0);
			assertTrue(testTask.getName().equals("Jon Doe"));
			
			// Update firstName to "Smith"
			testTask.setName("Smith");
			assertTrue(testTask.getName().equals("Smith"));
		}
		
		// Update description test
		@Test
		void testUpdatPhoneNumber() {
			TaskService taskService = new TaskService();
			
			// Add task with a unique id, default description should be "test description"
			taskService.addTask("11111111");
			Task testtask = taskService.tasks.get(0);
			assertTrue(testtask.getDescription().equals("test description"));
			
			// Update description to "1111111111"
			testtask.setDescription("1111111111");
			assertTrue(testtask.getDescription().equals("1111111111"));
		}
		
		

}
