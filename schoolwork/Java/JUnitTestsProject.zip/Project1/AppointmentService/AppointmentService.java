package main.java;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
    public ArrayList<Appointment> appointments;

    //Constructor
    public AppointmentService() {
        this.appointments = new ArrayList<Appointment>();
    }

    public void addAppointment(String id) {
        Date appointmentDate = new Date();
        // if appointments list is empty, add new Appointment
        if (appointments.size() == 0) {
            Appointment newAppointment = new Appointment(id, appointmentDate, "test description");
            appointments.add(newAppointment);
            return;
        }
        // else, check if id exists, if not, add id
        else {
            for (int i = 0; i < appointments.size(); i++) {
                if (appointments.get(i).getId().equals(id)) {
                    throw new IllegalArgumentException("ID already exists");
                }
            }

            Appointment newAppointment = new Appointment(id, appointmentDate, "test description");
            appointments.add(newAppointment);
        }
    }

    // Delete Appointment method
    public void deleteAppointment(String id) {
        // If Appointment id found, remove Appointment
        for (int i = 0; i < appointments.size(); i++) {
            if (appointments.get(i).getId().equals(id)) {
                appointments.remove(i);
                return;
            }
        }
        // If no ID not found, throw exception
        throw new IllegalArgumentException("ID doesn't exist");

    }

}