package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contact.Contact;
import contact.ContactService;

class ContactServiceTest {

	// test to make sure contacts array is initialized as empty ArrayList
	@Test
	void testContactsList() {
		ContactService contactService = new ContactService();
		
		assertTrue(contactService.contacts.size() == 0);
	}
	
	
	@Test
	void testAddExistingContact() {
		ContactService contactService = new ContactService();
		
		// Add first contact
		contactService.addContact("12345678");
		assertTrue(contactService.contacts.size() != 0);
		// add second contact with same ID
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact("12345678");
		});
	}
	
	// Delete non-existing contact test
	@Test
	void testDeleteNonExistingContact() {
		ContactService contactService = new ContactService();
		
		// Add first contact
		contactService.addContact("12345678");
		
		// Try to remove non-existing contact
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.deleteContact("11111111");
		});
	}
	
	// Delete existing contact test
	@Test
	void testExistingContact( ) {
		ContactService contactService = new ContactService();
		
		// Add first contact
		contactService.addContact("12345678");
		
		// Remove existing contact
		contactService.deleteContact("12345678");
		
		// Test that Contact was removed and contacts ArrayList is empty again
		assertTrue(contactService.contacts.size() == 0);
	}
	
	// Update firstName test
	@Test
	void testUpdateFirstName() {
		ContactService contactService = new ContactService();
		
		// Add contact with a unique id, default firstName should be "Jon"
		contactService.addContact("11111111");
		Contact testContact = contactService.contacts.get(0);
		assertTrue(testContact.getFirstName().equals("Jon"));
		
		// Update firstName to "Smith"
		testContact.setFirstName("Smith");
		assertTrue(testContact.getFirstName().equals("Smith"));
	}
	
	// Update lastName test
		@Test
		void testUpdateLastName() {
			ContactService contactService = new ContactService();
			
			// Add contact with a unique id, default firstName should be "Doe"
			contactService.addContact("11111111");
			Contact testContact = contactService.contacts.get(0);
			assertTrue(testContact.getLastName().equals("Doe"));
			
			// Update firstName to "Smith"
			testContact.setLastName("Smith");
			assertTrue(testContact.getLastName().equals("Smith"));
		}
		
		// Update phoneNumber test
		@Test
		void testUpdatPhoneNumber() {
			ContactService contactService = new ContactService();
			
			// Add contact with a unique id, default phoneNumber should be "1234567890"
			contactService.addContact("11111111");
			Contact testContact = contactService.contacts.get(0);
			assertTrue(testContact.getPhoneNumber().equals("1234567890"));
			
			// Update firstName to "1111111111"
			testContact.setPhoneNumber("1111111111");
			assertTrue(testContact.getPhoneNumber().equals("1111111111"));
		}
		
		// Update address test
		@Test
		void testUpdateAddress() {
			ContactService contactService = new ContactService();
			
			// Add contact with a unique id, default firstName should be "123 Main St."
			contactService.addContact("11111111");
			Contact testContact = contactService.contacts.get(0);
			assertTrue(testContact.getAddress().equals("123 Main St."));
			
			// Update firstName to "222 Smith St."
			testContact.setAddress("222 Smith St.");
			assertTrue(testContact.getAddress().equals("222 Smith St."));
		}

}
