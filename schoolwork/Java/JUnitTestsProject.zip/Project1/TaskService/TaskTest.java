package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import task.Task;



class TaskTest {

	// test to make sure tasks array is initialized as empty ArrayList
	@Test
	void testTasksList() {
		Task task = new Task("123456789", "Jon Doe", "test description");
		
		assertTrue(task.getId().equals("123456789"));
		assertTrue(task.getName().equals("Jon Doe"));
		assertTrue(task.getDescription().equals("test description"));
	}
	
	// Id tests
		@Test
		void testIdTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("1234567811122331", "Jon", "Doe");
			});
		}
		@Test
		void testIdNull( ) {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task(null, "Jon", "Doe");
			});
		}
		
		
		// Name tests
		@Test
		void testFirstNameTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("12345678", "JonathanTooLong ffffffffffff", "test description");
			});
		}
		@Test
		void testfirstNameNull( ) {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("12345678", null, "Doe");
			});
		}
		
		
		// Description tests
		@Test
		void testAddressTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("12345678", "Jon", "123 Main St. This String is Way too long"
						+ "											 Because it is greater than 50 characters in length");
			});
		}
		@Test
		void testAddressNull( ) {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("12345678", "Jon", null);
			});
		}
		
		
		
}




