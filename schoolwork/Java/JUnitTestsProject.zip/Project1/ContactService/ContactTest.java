package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contact.Contact;

class ContactTest {
	
	// Constructor test
	@Test
	void testContact() {
		Contact contact = new Contact("123456789", "Jon", "Doe",
									  "1234567890","123 Main St.");
		assertTrue(contact.getId().equals("123456789"));
		assertTrue(contact.getFirstName().equals("Jon"));
		assertTrue(contact.getLastName().equals("Doe"));
		assertTrue(contact.getPhoneNumber().equals("1234567890"));
		assertTrue(contact.getAddress().equals("123 Main St."));
	}
	
	// Id tests
	@Test
	void testIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567811122331", "Jon", "Doe", "1234567890", "123 Main St.");
		});
	}
	@Test
	void testIdNull( ) {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Jon", "Doe", "1234567890", "123 Main St.");
		});
	}
	
	// First Name tests
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "JonathanTooLong", "Doe", "1234567890", "123 Main St.");
		});
	}
	@Test
	void testfirstNameNull( ) {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", null, "Doe", "1234567890", "123 Main St.");
		});
	}
	
	// Last Name tests
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Jon", "DoeTooLongDoe", "1234567890", "123 Main St.");
		});
	}
	@Test
	void testLastNameNull( ) {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Jon", null, "1234567890", "123 Main St.");
		});
	}
	
	// Phone Number tests
	@Test
	void testPhoneNumberTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Jona", "Doe", "123456789", "123 Main St.");
		});
	}
	@Test
	void testPhoneNumberTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Jon", "Doe", "1234567890111", "123 Main St.");
		});
	}
	@Test
	void testPhoneNumberNull( ) {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Jon", "Doe", null, "123 Main St.");
		});
	}
	
	// Address tests
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Jon", "Doe", "1234567890", "123 Main St. This String is Way too long"
					+ "											 Because it is greater than 30 characters in length");
		});
	}
	@Test
	void testAddressNull( ) {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678", "Jon", "Doe", "1234567890", null);
		});
	}
}